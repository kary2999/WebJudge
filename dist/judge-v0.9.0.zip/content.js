// content.js — slim version (v0.9.0)
// 跑在每一个 frame(顶层 + 所有 iframe,见 manifest.json all_frames: true)。
//
// 职责只有 3 件:
//   1. (顶层) 启动 Web Vitals 观察者
//   2. 监听 inject.js (MAIN world) 派发的 __PI_API_CAPTURE__ 事件,记下捕获的 fetch/XHR
//   3. 暴露 window.__JUDGE_DUMP_RAW__() 返回本 frame 的原始数据
//
// 所有"分析"(分类、归责、网络评分、生成报告等)都搬到了 analyzer.js,
// 由 popup / report 上下文里调用。这样 content.js 在 iframe 里也只跑必要逻辑,
// 由调度方(popup)用 chrome.scripting.executeScript({ allFrames: true })
// 把所有 frame 的原始数据收回来再合并分析。

(function () {
  if (window.__JUDGE_INSTALLED__) return;
  window.__JUDGE_INSTALLED__ = true;

  const isTop = window === window.top;

  // ---------- Web Vitals ----------
  const vitals = { LCP: null, FCP: null, CLS: 0, INP: null, longTasks: [] };

  function safeObserve(type, cb, opts) {
    try {
      const po = new PerformanceObserver((list) => { for (const e of list.getEntries()) cb(e); });
      po.observe(opts || { type, buffered: true });
      return po;
    } catch (_) { return null; }
  }

  if (isTop) {
    safeObserve('largest-contentful-paint', (e) => {
      vitals.LCP = {
        value: e.startTime,
        element: e.element ? (e.element.tagName + (e.element.id ? '#' + e.element.id : '')) : null,
      };
    });
    safeObserve('paint', (e) => { if (e.name === 'first-contentful-paint') vitals.FCP = { value: e.startTime }; });
    safeObserve('layout-shift', (e) => { if (!e.hadRecentInput) vitals.CLS += e.value; });
    safeObserve('event', (e) => {
      if (e.interactionId) {
        const d = e.duration;
        if (!vitals.INP || d > vitals.INP.value) vitals.INP = { value: d, name: e.name };
      }
    }, { type: 'event', buffered: true, durationThreshold: 40 });
    safeObserve('longtask', (e) => { vitals.longTasks.push({ startTime: e.startTime, duration: e.duration }); });
  }

  // ---------- inject.js (MAIN world) 的 fetch/XHR 捕获事件 ----------
  const captured = [];
  window.addEventListener('__PI_API_CAPTURE__', (e) => {
    try { captured.push(JSON.parse(e.detail)); } catch (_) { /* ignore */ }
  });

  // ---------- 资源条目转纯对象(跨 isolated/MAIN 边界要可序列化) ----------
  function plainResource(e) {
    return {
      name: e.name,
      initiatorType: e.initiatorType || '',
      nextHopProtocol: e.nextHopProtocol || '',
      startTime: e.startTime,
      domainLookupStart: e.domainLookupStart,
      domainLookupEnd: e.domainLookupEnd,
      connectStart: e.connectStart,
      connectEnd: e.connectEnd,
      secureConnectionStart: e.secureConnectionStart,
      requestStart: e.requestStart,
      responseStart: e.responseStart,
      responseEnd: e.responseEnd,
      duration: e.duration,
      transferSize: e.transferSize || 0,
      encodedBodySize: e.encodedBodySize || 0,
      decodedBodySize: e.decodedBodySize || 0,
    };
  }

  function navigationSummary() {
    const nav = performance.getEntriesByType('navigation')[0];
    if (!nav) return null;
    return {
      type: nav.type,
      startTime: nav.startTime,
      duration: nav.duration,
      ttfb: Math.max(0, nav.responseStart - nav.requestStart),
      domContentLoaded: nav.domContentLoadedEventEnd,
      loadEvent: nav.loadEventEnd,
      transferSize: nav.transferSize || 0,
      protocol: nav.nextHopProtocol || '',
    };
  }

  function envInfo() {
    return {
      url: location.href,
      title: document.title,
      userAgent: navigator.userAgent,
      viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio },
      connection: navigator.connection ? {
        effectiveType: navigator.connection.effectiveType,
        downlink: navigator.connection.downlink,
        rtt: navigator.connection.rtt,
        saveData: navigator.connection.saveData,
        type: navigator.connection.type || null,
      } : null,
      memory: performance.memory ? {
        usedJSHeapMB: Math.round(performance.memory.usedJSHeapSize / 1048576),
        totalJSHeapMB: Math.round(performance.memory.totalJSHeapSize / 1048576),
        jsHeapSizeLimitMB: Math.round(performance.memory.jsHeapSizeLimit / 1048576),
      } : null,
    };
  }

  // ---------- 主动探测(供编排方调用) ----------
  // 暴露在 window 上,让 popup/orchestrator 通过 executeScript 在指定 frame 执行
  async function activeRttProbe(target, sampleCount, timeoutMs) {
    sampleCount = Math.max(1, Math.min(20, sampleCount || 5));
    timeoutMs = Math.max(500, Math.min(15000, timeoutMs || 4000));
    const samples = [];
    const errors = [];
    const startT = performance.now();
    for (let i = 0; i < sampleCount; i++) {
      const t0 = performance.now();
      let timedOut = false;
      try {
        const ctrl = new AbortController();
        const tid = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
        const url = target + (target.includes('?') ? '&' : '?') + '__judgeProbe=' + Date.now() + '-' + i;
        const resp = await fetch(url, {
          method: 'GET',
          cache: 'no-store',
          credentials: 'omit',
          mode: 'no-cors',
          signal: ctrl.signal,
        });
        clearTimeout(tid);
        try { await resp.arrayBuffer(); } catch (_) { /* opaque/no-cors */ }
        samples.push(performance.now() - t0);
      } catch (err) {
        errors.push({ msg: String((err && err.message) || err), timedOut, elapsed: performance.now() - t0 });
      }
      await new Promise((r) => setTimeout(r, 60));
    }
    return { samples, errors, totalMs: performance.now() - startT };
  }

  window.__JUDGE_PROBE__ = activeRttProbe;

  // ---------- 主入口:把本 frame 的原始数据吐出来 ----------
  window.__JUDGE_DUMP_RAW__ = function () {
    return {
      isTop,
      timeOrigin: performance.timeOrigin,
      frameUrl: location.href,
      frameOrigin: location.origin,
      env: isTop ? envInfo() : null,
      navigation: isTop ? navigationSummary() : null,
      vitals: isTop ? {
        LCP: vitals.LCP, FCP: vitals.FCP, CLS: vitals.CLS, INP: vitals.INP,
        longTasks: vitals.longTasks.slice(),
      } : null,
      resources: performance.getEntriesByType('resource').map(plainResource),
      captured: captured.slice(),
    };
  };
})();
