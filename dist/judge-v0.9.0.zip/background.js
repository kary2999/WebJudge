// Background service worker: relays JUDGE_OPEN_REPORT and hands payload to
// the freshly opened report.html tab.
//
// Race-condition fix (v0.8.1):
//   Old flow opened the tab *first*, then wrote to chrome.storage.local.
//   The report.html page started loading immediately and its loadReport()
//   could run BEFORE the storage write committed — producing an empty payload.
//   Users saw "未能获取报告数据" and had to click 4-5 times before one attempt
//   happened to win the race.
//
//   New flow:
//     1. Generate a unique key.
//     2. AWAIT storage.local.set(...)   — fully commit payload first.
//     3. open the tab at  report.html#<key>   — page reads key from URL hash.
//   The page can never be loaded with un-persisted data.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'JUDGE_OPEN_REPORT') {
    (async () => {
      try {
        // 1) Generate a collision-free storage key
        const key = 'judge_report_' + Date.now().toString(36) +
                    '_' + Math.random().toString(36).slice(2, 10);

        // 2) Commit payload to storage BEFORE opening the tab
        await chrome.storage.local.set({ [key]: msg.payload });

        // 3) Open the tab with key embedded in URL hash
        const url = chrome.runtime.getURL('report.html') + '#' + key;
        const tab = await chrome.tabs.create({ url });

        sendResponse({ ok: true, tabId: tab.id, key });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // keep the channel open for async sendResponse
  }
});

// Opportunistic cleanup: drop any judge_report_* entries older than 1 hour.
// (Extension's service worker wakes up on popup clicks; we piggy-back.)
chrome.runtime.onStartup.addListener(cleanupStaleReports);
chrome.runtime.onInstalled.addListener(cleanupStaleReports);

async function cleanupStaleReports() {
  try {
    const all = await chrome.storage.local.get(null);
    const now = Date.now();
    const CUTOFF = 60 * 60 * 1000; // 1 hour
    const toDelete = [];
    for (const k of Object.keys(all)) {
      if (!k.startsWith('judge_report_')) continue;
      // Our keys embed Date.now() in base36 as second segment
      const m = /^judge_report_([0-9a-z]+)_/.exec(k);
      if (!m) continue;
      const createdAt = parseInt(m[1], 36);
      if (!isFinite(createdAt)) continue;
      if (now - createdAt > CUTOFF) toDelete.push(k);
    }
    if (toDelete.length) await chrome.storage.local.remove(toDelete);
  } catch (_) { /* best-effort */ }
}
