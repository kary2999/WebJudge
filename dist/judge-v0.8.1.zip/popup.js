// popup.js - pulls report from active tab's content script, renders overview,
// and generates a complete PDF report entirely inside the popup (no print dialog).

const $ = (sel) => document.querySelector(sel);

let currentReport = null;
let currentTabId = null;
let currentIp = null;   // public IP for watermark, best-effort

const VITAL_THRESHOLDS = {
  LCP: [2500, 4000], FCP: [1800, 3000], CLS: [0.1, 0.25],
  INP: [200, 500], TTFB: [800, 1800],
};

// 大白话 Web Vitals 映射
const VITAL_LABELS = {
  LCP:  { icon: '🎯', name: '首屏主内容出现',
          good: '很快', warn: '稍慢', bad: '太慢',
          explain: '用户从点开到看到主要内容的时间' },
  FCP:  { icon: '📷', name: '页面开始出内容',
          good: '很快', warn: '有点慢', bad: '明显慢',
          explain: '浏览器第一次画出任何东西的时间' },
  CLS:  { icon: '📏', name: '页面抖动',
          good: '稳定',   warn: '偶有跳动', bad: '频繁跳动',
          explain: '排版突然错位把用户点错按钮的程度' },
  INP:  { icon: '⚡', name: '点击反应速度',
          good: '灵敏', warn: '有延迟', bad: '卡顿',
          explain: '用户点按钮到界面真正响应的时间' },
  TTFB: { icon: '🚀', name: '服务器响应速度',
          good: '快', warn: '一般', bad: '慢',
          explain: '浏览器发请求到服务器返回第一个字节的时间' },
};

function rateVital(name, value) {
  if (value == null) return 'unknown';
  const t = VITAL_THRESHOLDS[name];
  if (!t) return 'unknown';
  if (value <= t[0]) return 'good';
  if (value <= t[1]) return 'warn';
  return 'bad';
}

function fmtMs(v) { return v == null ? '—' : `${Math.round(v)} ms`; }
function fmtSec(v) { return v == null ? '—' : `${(v / 1000).toFixed(1)} 秒`; }

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function fetchReport(opts) {
  const tab = await getActiveTab();
  currentTabId = tab.id;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'JUDGE_PING' });
  } catch (_) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    } catch (e) {
      renderError('无法注入脚本,请在普通网页上使用 (不支持 chrome:// 页面)。');
      return null;
    }
  }

  try {
    const res = await chrome.tabs.sendMessage(tab.id, {
      type: 'JUDGE_GET_REPORT',
      withActiveProbe: !!(opts && opts.withActiveProbe),
      probeSampleCount: opts && opts.probeSampleCount,
    });
    if (!res || !res.ok) {
      renderError(res && res.error ? res.error : '采样失败');
      return null;
    }
    return res.report;
  } catch (e) {
    renderError(String(e.message || e));
    return null;
  }
}

function renderError(msg) {
  $('#slowList').innerHTML = `<li class="muted">${msg}</li>`;
}

// -------- 网络 0-100 评分 --------
function scoreNetwork(net) {
  if (!net) return { score: null, emoji: '❓', label: '未知', reasons: ['无网络数据'] };

  let score = 100;
  const reasons = [];

  const br = net.browserReported || {};
  // effectiveType 硬天花板
  const et = br.effectiveType;
  if (et === 'slow-2g' || et === '2g') { score = Math.min(score, 25); reasons.push(`浏览器判定 ${et}`); }
  else if (et === '3g') { score = Math.min(score, 60); reasons.push(`浏览器判定 ${et}`); }

  if (br.rttMs != null) {
    if (br.rttMs > 500) { score -= 25; reasons.push(`RTT ${br.rttMs}ms 偏高`); }
    else if (br.rttMs > 300) { score -= 15; reasons.push(`RTT ${br.rttMs}ms 稍高`); }
    else if (br.rttMs > 150) { score -= 6; }
  }
  if (br.downlinkMbps != null) {
    if (br.downlinkMbps < 0.5) { score -= 25; reasons.push(`下行仅 ${br.downlinkMbps} Mbps`); }
    else if (br.downlinkMbps < 1.5) { score -= 12; reasons.push(`下行 ${br.downlinkMbps} Mbps`); }
    else if (br.downlinkMbps < 4) { score -= 5; }
  }
  if (br.saveData) { score -= 5; reasons.push('开启省流量模式'); }

  const mDl = net.measured && net.measured.downloadThroughputMbps;
  if (mDl && mDl.p50 != null) {
    if (mDl.p50 < 1) { score -= 20; reasons.push(`实测下载中位 ${mDl.p50.toFixed(2)} Mbps`); }
    else if (mDl.p50 < 3) { score -= 8; reasons.push(`实测下载中位 ${mDl.p50.toFixed(2)} Mbps`); }
  }
  const mTtfb = net.measured && net.measured.ttfbStaticMs;
  if (mTtfb && mTtfb.p50 != null) {
    if (mTtfb.p50 > 800) { score -= 15; reasons.push(`静态 TTFB 中位 ${Math.round(mTtfb.p50)}ms`); }
    else if (mTtfb.p50 > 400) { score -= 6; reasons.push(`静态 TTFB 中位 ${Math.round(mTtfb.p50)}ms`); }
  }
  if (net.activeProbe) {
    if (net.activeProbe.p50 != null && net.activeProbe.p50 > 500) {
      score -= 12; reasons.push(`实测 RTT ${Math.round(net.activeProbe.p50)}ms`);
    }
    if (net.activeProbe.jitter != null && net.activeProbe.jitter > 200) {
      score -= 6; reasons.push(`RTT 抖动 ${Math.round(net.activeProbe.jitter)}ms`);
    }
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  let emoji, label;
  if (score >= 80)      { emoji = '💐'; label = '优秀'; }
  else if (score >= 65) { emoji = '👍'; label = '良好'; }
  else if (score >= 50) { emoji = '😐'; label = '一般'; }
  else                  { emoji = '💩'; label = '糟糕'; }

  return { score, emoji, label, reasons };
}

function renderNetwork(n) {
  if (!n) {
    $('#netSummary').innerHTML = '<div class="muted">无网络数据</div>';
    return;
  }
  const s = scoreNetwork(n);
  currentReport && (currentReport._netScore = s);
  const br = n.browserReported || {};
  const m = n.measured || {};
  const probe = n.activeProbe;

  const kv = [
    ['估算下行', br.downlinkMbps != null ? `${br.downlinkMbps} Mbps` : '—'],
    ['估算 RTT', br.rttMs != null ? `${br.rttMs} ms` : '—'],
    ['实测下载 p50', m.downloadThroughputMbps && m.downloadThroughputMbps.p50 != null ? `${m.downloadThroughputMbps.p50.toFixed(2)} Mbps` : '—'],
    ['静态 TTFB p50', m.ttfbStaticMs && m.ttfbStaticMs.p50 != null ? `${Math.round(m.ttfbStaticMs.p50)} ms` : '—'],
  ];
  if (probe && probe.p50 != null) {
    kv.push(['探测 RTT p50', `${Math.round(probe.p50)} ms`]);
    kv.push(['RTT 抖动', `${Math.round(probe.jitter)} ms`]);
  }
  const reasonHtml = s.reasons.length
    ? `<div class="net-reasons">${escHtml(s.reasons.slice(0, 3).join(' · '))}</div>`
    : '<div class="net-reasons muted">没有明显问题</div>';
  $('#netSummary').innerHTML = `
    <div class="score-row">
      <div class="score-emoji">${s.emoji}</div>
      <div class="score-num"><span class="num">${s.score}</span><span class="den">/100</span></div>
      <div class="score-label">${s.label}</div>
    </div>
    <div class="net-grid">
      ${kv.map(([k, v]) => `<div><span>${escHtml(k)}</span><span>${escHtml(v)}</span></div>`).join('')}
    </div>
    ${reasonHtml}
  `;
}

function escHtml(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]); }

// Web Vitals 白话版
function renderVitals(v, nav) {
  const ttfb = nav ? nav.ttfb : null;
  const items = [
    { key: 'LCP',  value: v.LCP ? v.LCP.value : null,  asSec: true  },
    { key: 'FCP',  value: v.FCP ? v.FCP.value : null,  asSec: true  },
    { key: 'CLS',  value: v.CLS, isCLS: true },
    { key: 'INP',  value: v.INP ? v.INP.value : null },
    { key: 'TTFB', value: ttfb },
  ];
  const html = items.map((it) => {
    const def = VITAL_LABELS[it.key];
    const rate = it.isCLS
      ? (it.value == null ? 'unknown' : it.value <= 0.1 ? 'good' : it.value <= 0.25 ? 'warn' : 'bad')
      : rateVital(it.key, it.value);
    const labelMap = { good: def.good, warn: def.warn, bad: def.bad, unknown: '—' };
    const iconMap  = { good: '✅', warn: '⚠️', bad: '❌', unknown: '—' };
    let display;
    if (it.value == null) display = '—';
    else if (it.isCLS) display = it.value.toFixed(2);
    else if (it.asSec && it.value >= 1000) display = fmtSec(it.value);
    else display = fmtMs(it.value);
    return `
      <div class="vital-row ${rate}">
        <div class="vital-icon">${def.icon}</div>
        <div class="vital-body">
          <div class="vital-name">${def.name}</div>
          <div class="vital-explain">${def.explain}</div>
        </div>
        <div class="vital-status">
          <div class="vital-value">${display}</div>
          <div class="vital-tag ${rate}">${iconMap[rate]} ${labelMap[rate]}</div>
        </div>
      </div>`;
  }).join('');
  const lt = v.longTasks.length;
  const ltRate = lt === 0 ? 'good' : lt > 5 ? 'bad' : 'warn';
  const ltIcon = { good: '✅', warn: '⚠️', bad: '❌' }[ltRate];
  const ltLabel = { good: '流畅', warn: '偶尔卡顿', bad: '明显卡顿' }[ltRate];
  $('#vitalsGrid').innerHTML = html + `
    <div class="vital-row ${ltRate}">
      <div class="vital-icon">🧱</div>
      <div class="vital-body">
        <div class="vital-name">主线程卡顿</div>
        <div class="vital-explain">页面 JS 长任务阻塞主线程的次数</div>
      </div>
      <div class="vital-status">
        <div class="vital-value">${lt} 次</div>
        <div class="vital-tag ${ltRate}">${ltIcon} ${ltLabel}</div>
      </div>
    </div>`;
}

function renderOverview(s, meta) {
  $('#overview').innerHTML = [
    ['请求总数', s.totalRequests],
    ['传输体积', `${s.totalTransferKB} KB`],
    ['慢接口 (>1s)', s.slowApis.length],
    ['HTTP 异常', s.failedApis.length],
    ['业务层失败', (s.bizFailedApis || []).length],
    ['浏览器排队', s.queued.length],
  ].map(([k, v]) => `<div><span>${escHtml(k)}</span><span>${escHtml(v)}</span></div>`).join('');
}

function renderSlowList(s) {
  const bizFailed = s.bizFailedApis || [];
  if (s.slowApis.length === 0 && s.failedApis.length === 0 && bizFailed.length === 0) {
    $('#slowList').innerHTML = '<li class="muted">没有慢接口,也没有异常状态 🎉</li>';
    return;
  }
  const items = [
    ...s.failedApis.slice(0, 2).map((r) => ({ r, badge: 'status-bad', label: `HTTP ${r.status}` })),
    ...bizFailed.slice(0, 2).map((r) => ({ r, badge: 'status-bad', label: `biz ${r.biz && r.biz.status}` })),
    ...s.slowApis.slice(0, 4).map((r) => ({ r, badge: r.slowReason || 'mixed', label: reasonLabel(r.slowReason) })),
  ].slice(0, 6);
  $('#slowList').innerHTML = items.map(({ r, badge, label }) => {
    const shortUrl = r.path && r.path.length <= 52 ? r.path : (r.path || r.url).slice(0, 52) + '…';
    const extra = [];
    if (r.serverReportedRuntimeMs != null) extra.push(`server ${Math.round(r.serverReportedRuntimeMs)}ms, Δ${Math.round(r.runtimeDelta)}ms`);
    if (r.biz && r.biz.message) extra.push(`msg: ${r.biz.message}`);
    const sub = extra.length ? `<span class="sub">${escHtml(extra.join(' · '))}</span>` : '';
    return `<li>
      <span class="url" title="${escHtml(r.url)}">${escHtml(shortUrl)}</span>
      <strong>${Math.round(r.duration)}ms</strong>
      <span class="tag ${escHtml(badge)}">${escHtml(label)}</span>
      ${sub}
    </li>`;
  }).join('');
}

function reasonLabel(r) {
  return ({
    'backend-slow': '后端慢',
    'browser-queue': '被浏览器排队',
    'download-heavy': '下载耗时',
    'frontend-overhead': '前端开销',
    'user-network': '用户网络慢',
    'mixed': '综合',
  })[r] || r || '';
}

function renderWarnings(sugs) {
  if (!sugs || sugs.length === 0) {
    $('#warnings').innerHTML = '<h2>优化建议</h2><div class="muted">暂无明显问题 ✨</div>';
    return;
  }
  $('#warnings').innerHTML = '<h2>优化建议</h2>' + sugs.slice(0, 4).map((s) =>
    `<div class="warn-item ${escHtml(s.level)}">
      <div class="t">${escHtml(s.title)}</div>
      <div class="d">${escHtml(s.detail)}</div>
    </div>`).join('');
}

// IP 水印的公网 IP 查询统一由 pdf-report.js (JudgePdfBuilder.fetchPublicIp) 提供

// -------- 摘要 / JSON --------
function buildTextSummary(r) {
  const lines = [];
  const s = r._netScore || scoreNetwork(r.network);
  lines.push(`【Judge 页面性能体检报告】`);
  lines.push(`URL: ${r.meta.url}`);
  lines.push(`标题: ${r.meta.title}`);
  lines.push(`采样时间: ${r.meta.generatedAt}`);
  lines.push('');
  lines.push(`用户网络评分: ${s.score} / 100  ${s.emoji} ${s.label}`);
  if (s.reasons.length) lines.push(`理由: ${s.reasons.slice(0, 5).join(' / ')}`);
  lines.push('');
  lines.push(`--- 概览 ---`);
  lines.push(`总请求 ${r.summary.totalRequests} | 慢接口 ${r.summary.slowApis.length} | HTTP 异常 ${r.summary.failedApis.length} | 业务层失败 ${(r.summary.bizFailedApis || []).length} | 排队 ${r.summary.queued.length}`);
  lines.push('');
  if ((r.summary.bizFailedApis || []).length > 0) {
    lines.push(`--- 业务层失败接口 (HTTP 200 但 biz.status != 0) ---`);
    r.summary.bizFailedApis.slice(0, 10).forEach((x, i) => {
      lines.push(`${i + 1}. [biz.status=${x.biz && x.biz.status}] ${x.method || ''} ${x.url}`);
      lines.push(`   message: ${(x.biz && x.biz.message) || ''}`);
    });
    lines.push('');
  }
  if (r.summary.failedApis.length > 0) {
    lines.push(`--- HTTP 状态异常接口 ---`);
    r.summary.failedApis.slice(0, 10).forEach((x, i) => {
      lines.push(`${i + 1}. [HTTP ${x.status}] ${x.method || ''} ${x.url}`);
    });
    lines.push('');
  }
  if (r.summary.slowApis.length > 0) {
    lines.push(`--- 慢接口 Top 10 ---`);
    r.summary.slowApis.slice(0, 10).forEach((x, i) => {
      lines.push(`${i + 1}. [${Math.round(x.duration)}ms] ${x.method || ''} ${x.url}`);
    });
  }
  return lines.join('\n');
}

async function copySummary() {
  if (!currentReport) return;
  try {
    await navigator.clipboard.writeText(buildTextSummary(currentReport));
    flash('copySummary', '已复制');
  } catch (_) { flash('copySummary', '失败'); }
}

function flash(id, text) {
  const btn = document.getElementById(id);
  const orig = btn.textContent;
  btn.textContent = text;
  setTimeout(() => (btn.textContent = orig), 1200);
}

// -------- 打开完整报告(v0.4 的全量 HTML 展示界面) --------
async function openReport() {
  if (!currentReport) return;
  const btn = $('#openReport');
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = '打开中…';
  try {
    await chrome.runtime.sendMessage({ type: 'JUDGE_OPEN_REPORT', payload: currentReport });
    window.close();
  } catch (e) {
    btn.textContent = '失败';
    console.error('打开完整报告失败', e);
    setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1400);
  }
}

// -------- 生成并下载 PDF --------
async function downloadPdf() {
  if (!currentReport) return;
  const btn = $('#downloadPdf');
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = '正在生成 PDF…';

  try {
    // 走共享模块,保证和"完整报告"页的 PDF 完全一致
    const blob = await window.JudgePdfBuilder.renderPdf(currentReport);
    const url = URL.createObjectURL(blob);
    const tsSafe = currentReport.meta.generatedAt.replace(/[:.]/g, '-');
    await chrome.downloads.download({ url, filename: `judge-report-${tsSafe}.pdf`, saveAs: false });
    btn.textContent = '已下载 ✓';
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  } catch (e) {
    console.error('PDF 生成失败', e);
    btn.textContent = '生成失败';
    alert('PDF 生成失败:' + (e && e.message || e));
  } finally {
    setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1600);
  }
}

// buildFullPdf 已移到 pdf-report.js (JudgePdfBuilder),popup 和 report 共用

function vitalVerdict(name, value) {
  if (value == null) return '—';
  const rate = rateVital(name, value);
  return { good: '✅ 正常', warn: '⚠️ 稍慢', bad: '❌ 太慢' }[rate] || '—';
}
function clsVerdict(value) {
  if (value == null) return '—';
  if (value <= 0.1) return '✅ 稳定';
  if (value <= 0.25) return '⚠️ 偶有跳动';
  return '❌ 频繁跳动';
}

// -------- 流程 --------

async function init(opts) {
  const r = await fetchReport(opts || {});
  if (!r) return;
  currentReport = r;
  renderNetwork(r.network);
  renderVitals(r.vitals, r.navigation);
  renderOverview(r.summary, r.meta);
  renderSlowList(r.summary);
  renderWarnings(r.suggestions);
}

async function runActiveProbe() {
  const btn = $('#probeBtn');
  const orig = btn.textContent;
  btn.disabled = true;
  btn.textContent = '探测中…';
  try {
    await init({ withActiveProbe: true, probeSampleCount: 6 });
    btn.textContent = '已刷新';
  } catch (_) {
    btn.textContent = '失败';
  }
  setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1400);
}

document.addEventListener('DOMContentLoaded', () => {
  init();
  // 提前预热公网 IP 查询(走共享模块的缓存),点 PDF 按钮时不等
  window.JudgePdfBuilder.fetchPublicIp().catch(() => {});
  $('#refresh').addEventListener('click', () => init());
  $('#copySummary').addEventListener('click', copySummary);
  $('#downloadPdf').addEventListener('click', downloadPdf);
  $('#openReport').addEventListener('click', openReport);
  $('#probeBtn').addEventListener('click', runActiveProbe);
});
