// Judge content script - runs in isolated world.
// Collects Web Vitals via PerformanceObserver, listens for API captures from
// the MAIN-world inject.js (fetch/XHR hook), correlates captured data with
// Resource Timing entries, and produces the full report on demand.

(function () {
  if (window.__JUDGE_INSTALLED__) return;
  window.__JUDGE_INSTALLED__ = true;

  // ---------- Web Vitals state ----------
  const vitals = {
    LCP: null,
    FCP: null,
    CLS: 0,
    INP: null,
    longTasks: [],
  };

  function safeObserve(type, cb, opts) {
    try {
      const po = new PerformanceObserver((list) => { for (const e of list.getEntries()) cb(e); });
      po.observe(opts || { type, buffered: true });
      return po;
    } catch (_) { return null; }
  }

  safeObserve('largest-contentful-paint', (e) => {
    vitals.LCP = { value: e.startTime, element: e.element ? (e.element.tagName + (e.element.id ? '#' + e.element.id : '')) : null };
  });
  safeObserve('paint', (e) => { if (e.name === 'first-contentful-paint') vitals.FCP = { value: e.startTime }; });
  safeObserve('layout-shift', (e) => { if (!e.hadRecentInput) vitals.CLS += e.value; });
  safeObserve('event', (e) => {
    if (e.interactionId) {
      const d = e.duration;
      if (!vitals.INP || d > vitals.INP.value) vitals.INP = { value: d, name: e.name };
    }
  }, { type: 'event', buffered: true, durationThreshold: 40 });
  safeObserve('longtask', (e) => { vitals.longTasks.push({ startTime: e.startTime, duration: e.duration }); });

  // ---------- API capture from MAIN world ----------
  /** @type {Array<object>} all captured API events */
  const captured = [];

  window.addEventListener('__PI_API_CAPTURE__', (e) => {
    try {
      const data = JSON.parse(e.detail);
      captured.push(data);
    } catch (_) { /* ignore */ }
  });

  // ---------- Helpers ----------
  const BROWSER_PARALLEL_LIMIT = 6;

  function getOrigin(url) { try { return new URL(url, location.href).origin; } catch (_) { return 'unknown'; } }
  function getPath(url) { try { return new URL(url, location.href).pathname; } catch (_) { return url; } }

  const FRONTEND_STATIC = new Set(['script', 'link', 'css', 'img', 'image', 'font', 'media', 'video', 'audio']);
  const BACKEND_API = new Set(['xmlhttprequest', 'fetch']);

  function categorize(initiator) {
    if (BACKEND_API.has(initiator)) return 'backend-api';
    if (FRONTEND_STATIC.has(initiator)) return 'frontend-static';
    if (initiator === 'navigation') return 'navigation';
    if (initiator === 'iframe' || initiator === 'frame') return 'iframe';
    return 'other';
  }

  function classifyInitiator(e) {
    const t = e.initiatorType || '';
    if (t === 'xmlhttprequest' || t === 'fetch') return t;
    if (t === 'link' || t === 'css') return 'css';
    if (t === 'img' || t === 'image') return 'img';
    return t || 'other';
  }

  // Match a resource entry to a captured API record (by URL + closest startTime).
  // CRITICAL: pairing must be 1-to-1 — otherwise when the same URL is called
  // multiple times, several resource rows can lay claim to the SAME capture,
  // leaving other captures (e.g. the one failed call among 4) orphaned.
  function findCaptureWithClaim(resEntry, usedSet) {
    const url = resEntry.name;
    let best = null;
    let bestDiff = Infinity;
    for (const c of captured) {
      if (usedSet.has(c)) continue;
      if (c.url !== url) continue;
      const diff = Math.abs((c.startTime || 0) - (resEntry.startTime || 0));
      if (diff < bestDiff && diff < 1500) {
        bestDiff = diff;
        best = c;
      }
    }
    if (best) usedSet.add(best);
    return best;
  }

  function buildResourceRows() {
    const nav = performance.getEntriesByType('navigation')[0];
    const resources = performance.getEntriesByType('resource');
    const usedCaptures = new Set(); // for 1-to-1 greedy pairing
    // Sort resources by startTime so earlier requests claim earlier captures first
    const sortedResources = resources.slice().sort((a, b) => a.startTime - b.startTime);
    const rows = sortedResources.map((e) => {
      const origin = getOrigin(e.name);
      const initiator = classifyInitiator(e);
      const category = categorize(initiator);
      const duration = e.duration;
      const queueTime = Math.max(0, (e.requestStart || 0) - (e.startTime || 0));
      const dnsTime = Math.max(0, (e.domainLookupEnd || 0) - (e.domainLookupStart || 0));
      const tcpTime = Math.max(0, (e.connectEnd || 0) - (e.connectStart || 0));
      const sslTime = e.secureConnectionStart ? Math.max(0, (e.connectEnd || 0) - e.secureConnectionStart) : 0;
      const serverTime = Math.max(0, (e.responseStart || 0) - (e.requestStart || 0));
      const downloadTime = Math.max(0, (e.responseEnd || 0) - (e.responseStart || 0));
      const transferSize = e.transferSize || 0;
      const encodedBodySize = e.encodedBodySize || 0;
      const decodedBodySize = e.decodedBodySize || 0;
      const fromCache = transferSize === 0 && decodedBodySize > 0;

      const row = {
        url: e.name,
        path: getPath(e.name),
        origin,
        initiator,
        category,
        nextHopProtocol: e.nextHopProtocol || '',
        startTime: e.startTime,
        responseEnd: e.responseEnd,
        duration,
        queueTime,
        dnsTime, tcpTime, sslTime,
        serverTime,
        downloadTime,
        transferSize,
        encodedBodySize,
        decodedBodySize,
        fromCache,
      };

      const cap = findCaptureWithClaim(e, usedCaptures);
      if (cap) {
        row.status = cap.status;
        row.statusText = cap.statusText;
        row.method = cap.method;
        row.ok = cap.ok;
        row.contentType = cap.contentType;
        row.extend = cap.extend || null;
        row.biz = cap.biz || null;
        row.bizStatus = cap.biz ? cap.biz.status : null;
        row.bizMessage = cap.biz ? cap.biz.message : null;
        row.isJson = !!cap.isJson;
        row.serverReportedRuntimeMs = cap.extend && cap.extend.runtimeMs != null ? cap.extend.runtimeMs : null;
        row.responseSnippet = cap.responseSnippet || '';
        row.bodyTruncated = !!cap.bodyTruncated;
        row.captureError = cap.error || null;
        if (row.serverReportedRuntimeMs != null) {
          row.runtimeDelta = row.duration - row.serverReportedRuntimeMs;
        }
      }

      return row;
    });

    // Also include any captured API calls that didn't match a resource entry.
    // After 1-to-1 pairing, anything still in `captured` but not in `usedCaptures`
    // is orphaned (no Resource Timing entry) and becomes its own row —
    // this is how a failed call among repeated same-URL calls gets surfaced.
    for (const c of captured) {
      if (usedCaptures.has(c)) continue;
      {
        const origin = getOrigin(c.url);
        rows.push({
          url: c.url,
          path: getPath(c.url),
          origin,
          initiator: c.hookType === 'xhr' ? 'xmlhttprequest' : 'fetch',
          category: 'backend-api',
          nextHopProtocol: '',
          startTime: c.startTime,
          responseEnd: c.endTime,
          duration: c.duration,
          queueTime: 0, dnsTime: 0, tcpTime: 0, sslTime: 0,
          serverTime: 0, downloadTime: 0,
          transferSize: 0, encodedBodySize: 0, decodedBodySize: 0,
          fromCache: false,
          status: c.status,
          statusText: c.statusText,
          method: c.method,
          ok: c.ok,
          contentType: c.contentType,
          extend: c.extend || null,
          biz: c.biz || null,
          bizStatus: c.biz ? c.biz.status : null,
          bizMessage: c.biz ? c.biz.message : null,
          isJson: !!c.isJson,
          serverReportedRuntimeMs: c.extend && c.extend.runtimeMs != null ? c.extend.runtimeMs : null,
          responseSnippet: c.responseSnippet || '',
          bodyTruncated: !!c.bodyTruncated,
          captureError: c.error || null,
          runtimeDelta: c.extend && c.extend.runtimeMs != null ? (c.duration - c.extend.runtimeMs) : undefined,
          noResourceTiming: true,
        });
      }
    }

    // Concurrency + queue detection
    for (const row of rows) {
      const concurrent = rows.filter(
        (r) => r !== row && r.origin === row.origin &&
          r.startTime <= row.startTime && r.responseEnd > row.startTime
      ).length;
      row.concurrentAtStart = concurrent;
      const networkWork = row.dnsTime + row.tcpTime + row.sslTime;
      row.browserQueued =
        concurrent >= BROWSER_PARALLEL_LIMIT &&
        row.queueTime - networkWork > 100 &&
        !row.fromCache;

      if (row.duration >= 1000) {
        if (row.serverReportedRuntimeMs != null && row.runtimeDelta > 300 && row.runtimeDelta > row.serverReportedRuntimeMs) {
          row.slowReason = row.browserQueued ? 'browser-queue' : 'frontend-overhead';
        } else if (row.browserQueued) {
          row.slowReason = 'browser-queue';
        } else if (row.serverTime / Math.max(row.duration, 1) > 0.7) {
          row.slowReason = 'backend-slow';
        } else if (row.downloadTime / Math.max(row.duration, 1) > 0.5) {
          row.slowReason = 'download-heavy';
        } else {
          row.slowReason = 'mixed';
        }
      } else {
        row.slowReason = null;
      }
    }

    return { rows, navigation: nav ? navigationTimingSummary(nav) : null };
  }

  function navigationTimingSummary(nav) {
    return {
      type: nav.type,
      startTime: nav.startTime,
      duration: nav.duration,
      ttfb: Math.max(0, nav.responseStart - nav.requestStart),
      domContentLoaded: nav.domContentLoadedEventEnd,
      loadEvent: nav.loadEventEnd,
      transferSize: nav.transferSize || 0,
      protocol: nav.nextHopProtocol || '',
    };
  }

  function summarize(rows) {
    const byOrigin = {};
    const byType = {};
    const byCategory = {
      'backend-api':    { count: 0, transfer: 0, totalDuration: 0 },
      'frontend-static':{ count: 0, transfer: 0, totalDuration: 0 },
      'navigation':     { count: 0, transfer: 0, totalDuration: 0 },
      'iframe':         { count: 0, transfer: 0, totalDuration: 0 },
      'other':          { count: 0, transfer: 0, totalDuration: 0 },
    };
    let totalTransfer = 0;
    let totalDecoded = 0;
    for (const r of rows) {
      byOrigin[r.origin] = (byOrigin[r.origin] || 0) + 1;
      byType[r.initiator] = byType[r.initiator] || { count: 0, transfer: 0 };
      byType[r.initiator].count++;
      byType[r.initiator].transfer += r.transferSize;
      byCategory[r.category].count++;
      byCategory[r.category].transfer += r.transferSize;
      byCategory[r.category].totalDuration += r.duration;
      totalTransfer += r.transferSize;
      totalDecoded += r.decodedBodySize;
    }

    const apiRows = rows.filter((r) => r.category === 'backend-api');

    const slowApis = apiRows
      .filter((r) => r.duration >= 1000)
      .sort((a, b) => b.duration - a.duration);

    const failedApis = apiRows.filter(
      (r) => r.status != null && !(r.status >= 200 && r.status < 300)
    ).sort((a, b) => (a.status || 0) - (b.status || 0));

    // Business-level failures: HTTP 2xx but response body status != success.
    // Different backends use different success codes: 0, 1, 200, "ok", "success", true.
    // We auto-detect the "dominant success value" to reduce false positives.
    const BIZ_SUCCESS_VALUES = new Set([0, '0', 1, '1', 200, '200', true, 'ok', 'OK', 'success', 'SUCCESS', 'succ', 'true']);
    function isBizSuccess(s) {
      if (s == null) return null; // unknown
      if (BIZ_SUCCESS_VALUES.has(s)) return true;
      if (typeof s === 'string' && /^(ok|success|true|succ)$/i.test(s)) return true;
      return false;
    }
    const bizFailedApis = apiRows.filter((r) => {
      if (!r.biz) return false;
      if (r.status && !(r.status >= 200 && r.status < 300)) return false; // already in failedApis
      const ok = isBizSuccess(r.biz.status);
      return ok === false; // only clearly failed, not unknown
    });

    const apisWithExtend = apiRows.filter((r) => r.extend);

    const runtimeMismatches = apisWithExtend
      .filter((r) => r.runtimeDelta != null && r.runtimeDelta > 300)
      .sort((a, b) => b.runtimeDelta - a.runtimeDelta);

    const topSlowAll = rows.slice().sort((a, b) => b.duration - a.duration).slice(0, 20);
    const queued = rows.filter((r) => r.browserQueued);
    const bigResources = rows
      .filter((r) => r.transferSize >= 300 * 1024)
      .sort((a, b) => b.transferSize - a.transferSize);

    const urlCount = {};
    for (const r of rows) urlCount[r.url] = (urlCount[r.url] || 0) + 1;
    const duplicates = Object.entries(urlCount)
      .filter(([_, n]) => n > 1)
      .map(([url, n]) => ({ url, count: n }));

    // Detect URLs with inconsistent outcomes (e.g. called 4 times, 3 ok / 1 fail).
    // We group backend-api rows by URL; if HTTP status or biz.status varies across
    // calls, the URL is inconsistent — the failed call goes into inconsistentCalls.
    const byUrl = new Map();
    for (const r of apiRows) {
      if (!byUrl.has(r.url)) byUrl.set(r.url, []);
      byUrl.get(r.url).push(r);
    }
    const inconsistentGroups = [];
    const inconsistentCalls = [];
    for (const [url, calls] of byUrl) {
      if (calls.length < 2) continue;
      const httpStatuses = new Set(calls.map((c) => c.status));
      const bizStatuses = new Set(calls.map((c) => c.biz ? c.biz.status : '__nobiz__'));
      if (httpStatuses.size > 1 || bizStatuses.size > 1) {
        const successCount = calls.filter((c) => {
          const httpOk = c.status >= 200 && c.status < 300;
          const bizOk = c.biz ? isBizSuccess(c.biz.status) !== false : true;
          return httpOk && bizOk;
        }).length;
        const failures = calls.filter((c) => {
          const httpOk = c.status >= 200 && c.status < 300;
          const bizOk = c.biz ? isBizSuccess(c.biz.status) !== false : true;
          return !(httpOk && bizOk);
        });
        inconsistentGroups.push({
          url,
          path: calls[0].path,
          totalCalls: calls.length,
          successCount,
          failureCount: failures.length,
          httpStatuses: Array.from(httpStatuses),
          bizStatuses: Array.from(bizStatuses).filter((s) => s !== '__nobiz__'),
          calls, // full rows
        });
        // also surface each failure as an individual row for tables
        for (const f of failures) inconsistentCalls.push(f);
      }
    }

    return {
      totalRequests: rows.length,
      totalTransferKB: Math.round(totalTransfer / 1024),
      totalDecodedKB: Math.round(totalDecoded / 1024),
      byOrigin, byType, byCategory,
      slowApis, failedApis, bizFailedApis, apisWithExtend, runtimeMismatches,
      inconsistentGroups, inconsistentCalls,
      topSlowAll, queued, bigResources, duplicates,
    };
  }

  function buildSuggestions(summary, vitalsCopy, network) {
    const s = [];
    // User-network suggestions — say this FIRST so open-ticket context is clear.
    if (network) {
      const userNetSlow = network.rating === 'poor' || network.rating === 'fair';
      const userNetCount = summary.slowApis.filter((r) => r.slowReason === 'user-network').length;
      if (network.rating === 'poor') {
        s.push({ level: 'error',
          title: `用户网络环境较差 (评级: POOR)`,
          detail: `${(network.ratingReasons || []).join('; ')}。慢可能不是系统问题 —— 建议用户:检查 WiFi 信号 / 切换到有线网 / 换网络环境后再测。` });
      } else if (network.rating === 'fair') {
        s.push({ level: 'warn',
          title: `用户网络环境一般 (评级: FAIR)`,
          detail: `${(network.ratingReasons || []).join('; ')}。部分"慢"可能是网络导致,不是后端。` });
      }
      if (userNetCount > 0) {
        s.push({ level: 'warn',
          title: `${userNetCount} 个慢接口标记为"用户网络导致"`,
          detail: '这些接口后端 TTFB 正常,但用户下载耗时长。不要归责后端 —— 先确认用户网络环境。' });
      }
      if (network.measured && network.measured.dnsMs && network.measured.dnsMs.p95 > 500) {
        s.push({ level: 'warn',
          title: `DNS 解析偏慢 (p95 ${Math.round(network.measured.dnsMs.p95)}ms)`,
          detail: '可能是公司 DNS 或用户本地 DNS 配置问题。尝试切到 Cloudflare 1.1.1.1 或 Google 8.8.8.8。' });
      }
    }
    if (summary.totalRequests > 80) {
      s.push({ level: 'warn', title: `请求数过多 (${summary.totalRequests})`,
        detail: '建议合并请求、图片懒加载、裁剪首屏依赖。超过 50 个请求会显著拖慢首屏。' });
    }
    const fs = summary.byCategory['frontend-static'];
    if (fs && fs.count > 60) {
      s.push({ level: 'warn',
        title: `前端静态资源 ${fs.count} 个 / ${Math.round(fs.transfer / 1024)} KB`,
        detail: '开启 HTTP 缓存、代码分割、图片懒加载 / WebP、清除无用依赖。' });
    }
    for (const [origin, n] of Object.entries(summary.byOrigin)) {
      if (n >= 20) {
        s.push({ level: 'warn', title: `同源 ${origin} 请求 ${n} 个`,
          detail: '浏览器同域只允许 6 个并行 HTTP/1.1 连接,后续排队。升级 HTTP/2/3 或静态资源拆 CDN 子域。' });
      }
    }
    if (summary.queued.length > 0) {
      s.push({ level: 'error', title: `检测到 ${summary.queued.length} 个请求被浏览器排队`,
        detail: '这些请求 time 看着慢,其实是前端把连接占满。不是后端慢 —— 减少并发请求数或升级 HTTP/2。' });
    }
    if (summary.runtimeMismatches.length > 0) {
      const top = summary.runtimeMismatches[0];
      s.push({ level: 'error',
        title: `${summary.runtimeMismatches.length} 个接口:后端 extend.runtime 远小于前端实测`,
        detail: `后端自报快,浏览器侧慢。差距来源:浏览器队列 / 网络传输 / 前端 JS。示例:${top.path} 后端 ${Math.round(top.serverReportedRuntimeMs)}ms,实测 ${Math.round(top.duration)}ms,差 ${Math.round(top.runtimeDelta)}ms。` });
    }
    if (summary.failedApis.length > 0) {
      s.push({ level: 'error', title: `${summary.failedApis.length} 个接口 HTTP 状态异常 (status ≠ 2xx)`,
        detail: '存在失败 / 重定向 / 服务端错误。请检查返回,可能造成功能不可用或重试风暴。' });
    }
    if (summary.bizFailedApis.length > 0) {
      s.push({ level: 'error', title: `${summary.bizFailedApis.length} 个接口业务失败 (HTTP 200 但响应 status 异常)`,
        detail: '服务器返回 200,但业务层 status / code / errcode 不是成功值(0/1/200/ok/success)。这类问题最容易被 HTTP 日志漏掉。点详情查看响应体。' });
    }
    if (summary.inconsistentGroups && summary.inconsistentGroups.length > 0) {
      const worst = summary.inconsistentGroups[0];
      s.push({ level: 'error',
        title: `${summary.inconsistentGroups.length} 个 URL 出现结果不一致 (多次请求部分成功/部分失败)`,
        detail: `同一个接口被调用多次,结果不统一。典型案例:${worst.path} 调用 ${worst.totalCalls} 次,成功 ${worst.successCount}/失败 ${worst.failureCount}。可能是偶发错误、并发竞态或重试掩盖。见"同 URL 不一致结果"区。` });
    }
    if (summary.slowApis.length > 0) {
      const backend = summary.slowApis.filter((r) => r.slowReason === 'backend-slow').length;
      if (backend > 0) {
        s.push({ level: 'error', title: `${backend} 个接口后端耗时占比 > 70%`,
          detail: '真后端慢 (TTFB 占主导),优化 SQL / 缓存 / 索引。' });
      }
    }
    if (summary.bigResources.length > 0) {
      const total = summary.bigResources.reduce((a, r) => a + r.transferSize, 0);
      s.push({ level: 'warn',
        title: `${summary.bigResources.length} 个大资源 (共 ${Math.round(total / 1024)} KB)`,
        detail: '图片 WebP/AVIF、JS Tree Shaking、CSS 清理。' });
    }
    if (summary.duplicates.length > 0) {
      s.push({ level: 'warn', title: `${summary.duplicates.length} 个 URL 被重复请求`,
        detail: '检查重复调用、缺失 Cache-Control / ETag,或前端未去重的并发请求。' });
    }
    if (vitalsCopy.LCP && vitalsCopy.LCP.value > 2500) {
      s.push({ level: 'error', title: `LCP ${Math.round(vitalsCopy.LCP.value)}ms 偏高`,
        detail: '首屏最大内容渲染慢。减小首屏图片、preload 关键资源、SSR 或骨架屏。' });
    }
    if (vitalsCopy.CLS > 0.1) {
      s.push({ level: 'warn', title: `CLS ${vitalsCopy.CLS.toFixed(3)} 偏高`,
        detail: '布局抖动明显。给图片/广告/iframe 预留固定尺寸。' });
    }
    if (vitalsCopy.INP && vitalsCopy.INP.value > 200) {
      s.push({ level: 'warn', title: `INP ${Math.round(vitalsCopy.INP.value)}ms 偏高`,
        detail: '交互卡顿。拆分长任务、减少主线程阻塞。' });
    }
    if (vitalsCopy.longTasks.length > 5) {
      s.push({ level: 'warn',
        title: `检测到 ${vitalsCopy.longTasks.length} 个主线程长任务 (>50ms)`,
        detail: '主线程阻塞导致点击/滚动卡顿。检查大型同步 JS、重型循环、第三方脚本。' });
    }
    return s;
  }

  // ---------- Network profile ----------
  function percentile(sortedNums, p) {
    if (!sortedNums.length) return null;
    const idx = Math.min(sortedNums.length - 1, Math.floor(sortedNums.length * p));
    return sortedNums[idx];
  }
  function avg(nums) {
    if (!nums.length) return null;
    return nums.reduce((a, b) => a + b, 0) / nums.length;
  }
  function stats(nums) {
    if (!nums.length) return null;
    const sorted = nums.slice().sort((a, b) => a - b);
    return {
      samples: sorted.length,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      avg: avg(sorted),
      p50: percentile(sorted, 0.5),
      p95: percentile(sorted, 0.95),
    };
  }

  function rankWorse(a, b) {
    const order = { excellent: 0, good: 1, fair: 2, poor: 3 };
    return (order[a] ?? 0) > (order[b] ?? 0) ? a : b;
  }

  function buildNetworkProfile(rows, activeProbe) {
    const conn = navigator.connection || null;
    const browserReported = conn ? {
      effectiveType: conn.effectiveType || null,
      downlinkMbps: conn.downlink != null ? conn.downlink : null,
      rttMs: conn.rtt != null ? conn.rtt : null,
      saveData: !!conn.saveData,
      type: conn.type || null,
    } : null;

    // Throughput from actually downloaded content (exclude cache hits & tiny/no-body resources)
    const throughputSamples = [];
    const dnsSamples = [];
    const tcpSamples = [];
    const sslSamples = [];
    const ttfbStaticSamples = []; // for static (non-API) resources — approximates "network baseline"
    for (const r of rows) {
      if (r.transferSize > 2000 && r.downloadTime > 5 && !r.fromCache) {
        // Mbps = (bytes * 8) / (seconds) / 1e6
        const mbps = (r.transferSize * 8) / (r.downloadTime / 1000) / 1_000_000;
        if (isFinite(mbps) && mbps > 0 && mbps < 10000) throughputSamples.push(mbps);
      }
      if (r.dnsTime > 0) dnsSamples.push(r.dnsTime);
      if (r.tcpTime > 0) tcpSamples.push(r.tcpTime);
      if (r.sslTime > 0) sslSamples.push(r.sslTime);
      if (r.category === 'frontend-static' && r.serverTime > 0) ttfbStaticSamples.push(r.serverTime);
    }

    const measured = {
      downloadThroughputMbps: stats(throughputSamples),
      dnsMs: stats(dnsSamples),
      tcpMs: stats(tcpSamples),
      sslMs: stats(sslSamples),
      ttfbStaticMs: stats(ttfbStaticSamples),
    };

    // Per-origin breakdown (top 8 by request count)
    const originBuckets = new Map();
    for (const r of rows) {
      if (!originBuckets.has(r.origin)) originBuckets.set(r.origin, { dns: [], tcp: [], ssl: [], ttfb: [], throughput: [], count: 0 });
      const b = originBuckets.get(r.origin);
      b.count++;
      if (r.dnsTime > 0) b.dns.push(r.dnsTime);
      if (r.tcpTime > 0) b.tcp.push(r.tcpTime);
      if (r.sslTime > 0) b.ssl.push(r.sslTime);
      if (r.serverTime > 0) b.ttfb.push(r.serverTime);
      if (r.transferSize > 2000 && r.downloadTime > 5 && !r.fromCache) {
        const mbps = (r.transferSize * 8) / (r.downloadTime / 1000) / 1_000_000;
        if (isFinite(mbps) && mbps > 0) b.throughput.push(mbps);
      }
    }
    const byOrigin = Array.from(originBuckets.entries())
      .map(([origin, b]) => ({
        origin, count: b.count,
        dnsP50: percentile(b.dns.sort((a, b) => a - b), 0.5),
        tcpP50: percentile(b.tcp.sort((a, b) => a - b), 0.5),
        sslP50: percentile(b.ssl.sort((a, b) => a - b), 0.5),
        ttfbP50: percentile(b.ttfb.sort((a, b) => a - b), 0.5),
        throughputP50: percentile(b.throughput.sort((a, b) => a - b), 0.5),
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    // Rating
    let rating = 'excellent';
    const reasons = [];
    if (browserReported) {
      const et = browserReported.effectiveType;
      if (et === 'slow-2g' || et === '2g') { rating = rankWorse(rating, 'poor'); reasons.push(`浏览器判定 ${et}`); }
      else if (et === '3g') { rating = rankWorse(rating, 'fair'); reasons.push(`浏览器判定 3g`); }
      if (browserReported.rttMs != null) {
        if (browserReported.rttMs > 500) { rating = rankWorse(rating, 'poor'); reasons.push(`估算 RTT ${browserReported.rttMs}ms`); }
        else if (browserReported.rttMs > 300) { rating = rankWorse(rating, 'fair'); reasons.push(`估算 RTT ${browserReported.rttMs}ms`); }
        else if (browserReported.rttMs > 150) { rating = rankWorse(rating, 'good'); }
      }
      if (browserReported.downlinkMbps != null) {
        if (browserReported.downlinkMbps < 0.5) { rating = rankWorse(rating, 'poor'); reasons.push(`估算下行 ${browserReported.downlinkMbps}Mbps`); }
        else if (browserReported.downlinkMbps < 1.5) { rating = rankWorse(rating, 'fair'); reasons.push(`估算下行 ${browserReported.downlinkMbps}Mbps`); }
        else if (browserReported.downlinkMbps < 4) { rating = rankWorse(rating, 'good'); }
      }
      if (browserReported.saveData) { rating = rankWorse(rating, 'fair'); reasons.push('用户开启了省流量模式'); }
    }
    if (measured.downloadThroughputMbps && measured.downloadThroughputMbps.p50 != null) {
      const p50 = measured.downloadThroughputMbps.p50;
      if (p50 < 1) { rating = rankWorse(rating, 'poor'); reasons.push(`实测中位速率 ${p50.toFixed(2)} Mbps`); }
      else if (p50 < 3) { rating = rankWorse(rating, 'fair'); reasons.push(`实测中位速率 ${p50.toFixed(2)} Mbps`); }
    }
    if (measured.ttfbStaticMs && measured.ttfbStaticMs.p50 != null) {
      const p50 = measured.ttfbStaticMs.p50;
      if (p50 > 800) { rating = rankWorse(rating, 'poor'); reasons.push(`静态资源 TTFB 中位 ${Math.round(p50)}ms`); }
      else if (p50 > 400) { rating = rankWorse(rating, 'fair'); reasons.push(`静态资源 TTFB 中位 ${Math.round(p50)}ms`); }
    }
    if (activeProbe && activeProbe.p50 != null) {
      if (activeProbe.p50 > 500) { rating = rankWorse(rating, 'poor'); reasons.push(`实测 RTT 中位 ${Math.round(activeProbe.p50)}ms`); }
      else if (activeProbe.p50 > 250) { rating = rankWorse(rating, 'fair'); reasons.push(`实测 RTT 中位 ${Math.round(activeProbe.p50)}ms`); }
    }

    return {
      browserReported,
      measured,
      byOrigin,
      activeProbe: activeProbe || null,
      rating,
      ratingReasons: reasons,
    };
  }

  // Active RTT probe — makes N small requests to the current origin's favicon.
  async function activeRttProbe(sampleCount) {
    sampleCount = Math.max(1, Math.min(20, sampleCount || 6));
    const target = location.origin + '/favicon.ico';
    const samples = [];
    const errors = [];
    for (let i = 0; i < sampleCount; i++) {
      const t0 = performance.now();
      try {
        const resp = await fetch(target + '?__judgeProbe=' + Date.now() + '-' + i, {
          method: 'GET',
          cache: 'no-store',
          credentials: 'omit',
        });
        // Consume body so we measure to end (favicon is tiny)
        await resp.arrayBuffer();
        samples.push(performance.now() - t0);
      } catch (err) {
        errors.push(String((err && err.message) || err));
      }
      // Small pause to avoid burst being rate-limited
      await new Promise((r) => setTimeout(r, 60));
    }
    const s = stats(samples);
    const jitter = samples.length > 1
      ? Math.max(...samples) - Math.min(...samples)
      : 0;
    return {
      target,
      requested: sampleCount,
      successCount: samples.length,
      failedCount: errors.length,
      samples,
      errors: errors.slice(0, 5),
      min: s ? s.min : null,
      max: s ? s.max : null,
      avg: s ? s.avg : null,
      p50: s ? s.p50 : null,
      p95: s ? s.p95 : null,
      jitter,
    };
  }

  function buildFullReport(activeProbe) {
    const { rows, navigation } = buildResourceRows();
    const network = buildNetworkProfile(rows, activeProbe);

    // Tag slow rows with 'user-network' when user's own network is the likely cause.
    // This happens ONLY when the user's network is demonstrably slow AND the request's
    // server time is small — i.e., backend was fast, but bytes took forever to arrive.
    const userNetSlow = network.rating === 'poor' || (
      network.measured.downloadThroughputMbps && network.measured.downloadThroughputMbps.p50 != null && network.measured.downloadThroughputMbps.p50 < 1.5
    );
    if (userNetSlow) {
      for (const row of rows) {
        if (row.duration < 1000) continue;
        // Only reassign from ambiguous categories, and only when server was fast.
        const backendFast = (row.serverReportedRuntimeMs != null && row.serverReportedRuntimeMs < 300)
          || (row.serverTime > 0 && row.serverTime < 300);
        if (!backendFast) continue;
        if (row.slowReason === 'backend-slow') continue;
        if (row.slowReason === 'browser-queue') continue;
        row.slowReason = 'user-network';
      }
    }

    const summary = summarize(rows);
    const vitalsCopy = {
      LCP: vitals.LCP, FCP: vitals.FCP, CLS: vitals.CLS, INP: vitals.INP,
      longTasks: vitals.longTasks.slice(),
    };
    const suggestions = buildSuggestions(summary, vitalsCopy, network);

    return {
      meta: {
        generatedAt: new Date().toISOString(),
        url: location.href,
        title: document.title,
        userAgent: navigator.userAgent,
        viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio },
        connection: navigator.connection ? {
          effectiveType: navigator.connection.effectiveType,
          downlink: navigator.connection.downlink,
          rtt: navigator.connection.rtt,
          saveData: navigator.connection.saveData,
        } : null,
        memory: performance.memory ? {
          usedJSHeapMB: Math.round(performance.memory.usedJSHeapSize / 1048576),
          totalJSHeapMB: Math.round(performance.memory.totalJSHeapSize / 1048576),
          jsHeapSizeLimitMB: Math.round(performance.memory.jsHeapSizeLimit / 1048576),
        } : null,
        capturedApiCount: captured.length,
      },
      vitals: vitalsCopy,
      navigation,
      network,
      summary,
      resources: rows,
      suggestions,
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'JUDGE_GET_REPORT') {
      if (msg.withActiveProbe) {
        activeRttProbe(msg.probeSampleCount || 6)
          .then((probe) => {
            try { sendResponse({ ok: true, report: buildFullReport(probe) }); }
            catch (err) { sendResponse({ ok: false, error: String((err && err.stack) || err) }); }
          })
          .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
        return true; // keep channel open
      }
      try { sendResponse({ ok: true, report: buildFullReport() }); }
      catch (err) { sendResponse({ ok: false, error: String((err && err.stack) || err) }); }
      return true;
    }
    if (msg && msg.type === 'JUDGE_PING') {
      sendResponse({ ok: true });
      return true;
    }
  });
})();
